pid = load("PID_VIND_01.mat");
dmc = load("DMC_WORK_v3101.mat");

figure(1)
hold on;
stairs(pid.y)
stairs(dmc.y)
legend("PID", "DMC")
title("WYJSCIE")
hold off;

figure(2)
hold on
stairs(pid.u)
title("Sterownaie")
stairs(dmc.u)
legend("PID", "DMC")
hold off