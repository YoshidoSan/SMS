lambda=3; %parametr lambda np. 1
D=30; %horyzont dynamiki (D)
N=10;%horyzont predykcji (N)
Nu=1; %horyzont sterowania (Nu)(ilosc przyszlych przyrostow wartosci sterowania)

%tu se s dać
% s_loda = load("Y_test_320.mat");
% s = (s_loda.y(301:333))/100;
% plot(s)
s_load = load("ODP_SKOK.mat");
s_first = s_load.y(165);
s=((s_load.y(166:1:215))-s_first)/1000;
plot(s)
% s=(s_load.y(166:1:215))/1000;

%macierz współczynników odpowiedzi skokowej wymiary(NxNu)
M=zeros(N,Nu); 
for i=1:N
 for j=1:Nu
  if (j<=i)             %wypelnianie macierzy trojkatnej dolnej M   
   M(i,j)=s(i-j+1);
  end
 end
end

I=eye(Nu);              %tworzenie macierzy jednostkowej o wymiarach NuxNu
K=(M'*M+lambda*I)\M';   %macierz K
Mp=zeros(N,D-1);        %macierz ma wymiary Nx(D-1)
%wypelnianie macierzy Mp
for i=1:N
 for j=1:D-1
  if i+j<=D
   Mp(i,j)=s(i+j)-s(j);
  else
   Mp(i,j)=s(D)-s(j);
  end    
 end
end

Ke=sum(K(1,:));         %współczynnik Ke
Ku=K(1,:)*Mp;           %współczynnik Ku

strjoin(arrayfun(@(x) num2str(x),Ku,'UniformOutput',false),'f, ')
